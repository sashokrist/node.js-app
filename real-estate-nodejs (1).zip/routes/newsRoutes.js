const express = require('express');
const router = express.Router();
const newsController = require('../controllers/newsController');

router.get('/', newsController.index);
router.get('/create', newsController.showCreateForm);
router.post('/create', newsController.create);

module.exports = router;
