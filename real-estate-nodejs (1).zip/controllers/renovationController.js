const pool = require('../models/db');

exports.index = async (req, res) => {
  const [renovations] = await pool.execute('SELECT * FROM renovations ORDER BY id DESC');
  res.render('renovations/index', { renovations });
};

exports.showCreateForm = (req, res) => {
  res.render('renovations/create');
};

exports.create = async (req, res) => {
  const { service_name, description } = req.body;
  await pool.execute('INSERT INTO renovations (service_name, description) VALUES (?, ?)', [service_name, description]);
  res.redirect('/admin/renovations');
};
