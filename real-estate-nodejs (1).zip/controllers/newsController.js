const pool = require('../models/db');

exports.index = async (req, res) => {
  const [news] = await pool.execute('SELECT * FROM news ORDER BY id DESC');
  res.render('news/index', { news });
};

exports.showCreateForm = (req, res) => {
  res.render('news/create');
};

exports.create = async (req, res) => {
  const { title, content } = req.body;
  await pool.execute('INSERT INTO news (title, content) VALUES (?, ?)', [title, content]);
  res.redirect('/admin/news');
};
