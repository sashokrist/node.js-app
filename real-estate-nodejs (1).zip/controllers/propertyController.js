const pool = require('../models/db');

exports.index = async (req, res) => {
  const [properties] = await pool.execute('SELECT * FROM properties ORDER BY id DESC');
  res.render('properties/index', { properties });
};

exports.showCreateForm = (req, res) => {
  res.render('properties/create');
};

exports.create = async (req, res) => {
  const { title, description } = req.body;
  await pool.execute('INSERT INTO properties (title, description) VALUES (?, ?)', [title, description]);
  res.redirect('/admin/properties');
};
